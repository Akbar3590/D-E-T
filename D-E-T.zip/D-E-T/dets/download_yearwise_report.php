<?php
session_start();
include('includes/dbconnection.php');

if (isset($_POST['fromdate']) && isset($_POST['todate'])) {
    $fdate = $_POST['fromdate'];
    $tdate = $_POST['todate'];
    $userid = $_SESSION['detsuid'];

    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=Yearwise_Expense_Report.csv");

    $output = fopen("php://output", "w");
    fputcsv($output, array('S.NO', 'Year', 'Expense Amount'));

    $query = mysqli_query($con, "SELECT YEAR(ExpenseDate) as rptyear, SUM(ExpenseCost) as totalyear FROM tblexpense WHERE (ExpenseDate BETWEEN '$fdate' AND '$tdate') AND (UserId='$userid') GROUP BY YEAR(ExpenseDate)");

    $cnt = 1;
    $totalsexp = 0;
    
    while ($row = mysqli_fetch_assoc($query)) {
        fputcsv($output, array($cnt, $row['rptyear'], $row['totalyear']));
        $totalsexp += $row['totalyear'];
        $cnt++;
    }

    // Add Grand Total
    fputcsv($output, array('', 'Grand Total', $totalsexp));

    fclose($output);
    exit();
} else {
    echo "Invalid request!";
}
?>
