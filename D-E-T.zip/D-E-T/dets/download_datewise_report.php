<?php
session_start();
include('includes/dbconnection.php');

if (isset($_POST['fromdate']) && isset($_POST['todate'])) {
    $fdate = $_POST['fromdate'];
    $tdate = $_POST['todate'];
    $userid = $_SESSION['detsuid'];

    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=Datewise_Expense_Report.csv");

    $output = fopen("php://output", "w");
    fputcsv($output, array('S.NO', 'Date', 'Expense Amount'));

    $query = mysqli_query($con, "SELECT ExpenseDate, SUM(ExpenseCost) as total FROM tblexpense WHERE (ExpenseDate BETWEEN '$fdate' AND '$tdate') AND (UserId='$userid') GROUP BY ExpenseDate");

    $cnt = 1;
    $totalsexp = 0;
    
    while ($row = mysqli_fetch_assoc($query)) {
        fputcsv($output, array($cnt, $row['ExpenseDate'], $row['total']));
        $totalsexp += $row['total'];
        $cnt++;
    }

    // Add Grand Total
    fputcsv($output, array('', 'Grand Total', $totalsexp));

    fclose($output);
    exit();
} else {
    echo "Invalid request!";
}
?>
