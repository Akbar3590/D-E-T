<?php
$userid = $_SESSION['detsuid'];
$currentMonth = date('m');  // Current month
$currentYear = date('Y');   // Current year

// Query to get total expenses for the current month
$query = mysqli_query($con, "SELECT SUM(ExpenseCost) as total FROM tblexpense WHERE UserId='$userid' AND MONTH(ExpenseDate)='$currentMonth' AND YEAR(ExpenseDate)='$currentYear'");

$row = mysqli_fetch_assoc($query);
$totalExpense = $row['total'] ?? 0;  // Agar koi expense nahi hai to 0 set hoga

echo "Total Monthly Expense: " . $totalExpense;
?>
